package com.stockpro.app.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "products", indices = [Index(value = ["sku"], unique = true)])
data class Product(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sku: String,
    val name: String,
    val costMinor: Long,
    val priceMinor: Long,
    val quantity: Int,
    val minimum: Int,
    val currency: String = "USD",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "suppliers")
data class Supplier(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val contact: String = "",
    val notes: String = ""
)

@Entity(tableName = "sales")
data class Sale(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val date: Long = System.currentTimeMillis(),
    val productId: Long,
    val productNameSnapshot: String,
    val quantity: Int,
    val unitPriceMinor: Long,
    val unitCostMinor: Long,
    val currency: String,
    val totalMinor: Long,
    val grossProfitMinor: Long
)

@Entity(tableName = "purchases")
data class Purchase(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val date: Long = System.currentTimeMillis(),
    val productId: Long,
    val productNameSnapshot: String,
    val quantity: Int,
    val unitCostMinor: Long,
    val currency: String,
    val totalMinor: Long,
    val supplierId: Long? = null
)

@Entity(tableName = "stock_movements")
data class StockMovement(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val date: Long = System.currentTimeMillis(),
    val productId: Long,
    val productNameSnapshot: String,
    val type: String,
    val quantityDelta: Int,
    val quantityBefore: Int,
    val quantityAfter: Int,
    val reason: String
)
