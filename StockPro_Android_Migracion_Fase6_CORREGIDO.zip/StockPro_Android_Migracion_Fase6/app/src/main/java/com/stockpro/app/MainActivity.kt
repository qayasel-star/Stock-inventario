package com.stockpro.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.room.Room
import com.stockpro.app.data.*
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.util.Locale

private val deepGreen = androidx.compose.ui.graphics.Color(0xFF071B18)
private val panel = androidx.compose.ui.graphics.Color(0xFF0D2923)
private val lime = androidx.compose.ui.graphics.Color(0xFFC8F169)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = Room.databaseBuilder(applicationContext, StockDatabase::class.java, "stockpro.db").build()
        setContent { StockProApp(db.dao()) }
    }
}

private enum class Screen(val label: String) {
    HOME("Inicio"), PRODUCTS("Productos"), SALES("Ventas"), PURCHASES("Compras"),
    SUPPLIERS("Proveedores"), ANALYSIS("Análisis"), SETTINGS("Ajustes")
}

@Composable
private fun StockProApp(dao: StockDao) {
    var screen by remember { mutableStateOf(Screen.HOME) }
    val products by dao.observeProducts().collectAsStateWithLifecycle(initialValue = emptyList())
    val suppliers by dao.observeSuppliers().collectAsStateWithLifecycle(initialValue = emptyList())
    val sales by dao.observeSales().collectAsStateWithLifecycle(initialValue = emptyList())
    val purchases by dao.observePurchases().collectAsStateWithLifecycle(initialValue = emptyList())
    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    MaterialTheme(colorScheme = darkColorScheme(
        primary = lime, onPrimary = deepGreen, background = deepGreen, surface = panel,
        onBackground = androidx.compose.ui.graphics.Color.White,
        onSurface = androidx.compose.ui.graphics.Color.White,
        secondary = androidx.compose.ui.graphics.Color(0xFF40D99B)
    )) {
        Scaffold(
            containerColor = deepGreen,
            snackbarHost = { SnackbarHost(snackbar) },
            bottomBar = {
                NavigationBar(containerColor = panel) {
                    Screen.values().forEach { item ->
                        NavigationBarItem(
                            selected = screen == item, onClick = { screen = item },
                            icon = {
                                Icon(when (item) {
                                    Screen.HOME -> Icons.Default.Dashboard
                                    Screen.PRODUCTS -> Icons.Default.Inventory2
                                    Screen.SALES -> Icons.Default.PointOfSale
                                    Screen.PURCHASES -> Icons.Default.LocalShipping
                                    Screen.SUPPLIERS -> Icons.Default.People
                                    Screen.ANALYSIS -> Icons.Default.Analytics
                                    Screen.SETTINGS -> Icons.Default.Settings
                                }, contentDescription = item.label)
                            },
                            label = { Text(item.label, maxLines = 1) }
                        )
                    }
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp, vertical = 10.dp)) {
                Text("StockPro", style = MaterialTheme.typography.headlineMedium, color = lime)
                Text(screen.label, style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(12.dp))
                when (screen) {
                    Screen.HOME -> HomeScreen(products, sales, purchases)
                    Screen.PRODUCTS -> ProductsScreen(products) { sku, name, cost, price, qty, min ->
                        scope.launch {
                            try {
                                require(sku.isNotBlank() && name.isNotBlank()) { "SKU y nombre son obligatorios." }
                                require(cost >= 0 && price >= 0 && qty >= 0 && min >= 0) { "No se permiten valores negativos." }
                                dao.insertProduct(Product(sku = sku.trim(), name = name.trim(), costMinor = cost, priceMinor = price, quantity = qty, minimum = min))
                                snackbar.showSnackbar("Producto guardado")
                            } catch (e: Exception) {
                                snackbar.showSnackbar(e.message ?: "No se pudo guardar. Comprueba si el SKU ya existe.")
                            }
                        }
                    }
                    Screen.SALES -> TransactionScreen(
                        products = products, suppliers = emptyList(), showSupplier = false,
                        actionLabel = "Registrar venta",
                        onSubmit = { id, qty, _, _ ->
                            scope.launch {
                                val result = runCatching { dao.registerSale(id, qty).getOrThrow() }
                                snackbar.showSnackbar(result.fold({ "Venta registrada #$it" }, { it.message ?: "No se pudo registrar la venta" }))
                            }
                        },
                        history = sales.map { "${it.productNameSnapshot} · ${it.quantity} uds. · ${money(it.totalMinor, it.currency)}" }
                    )
                    Screen.PURCHASES -> TransactionScreen(
                        products = products, suppliers = suppliers, showSupplier = true,
                        actionLabel = "Registrar compra",
                        onSubmit = { id, qty, cost, supplierId ->
                            scope.launch {
                                val result = runCatching { dao.registerPurchase(id, qty, cost, supplierId).getOrThrow() }
                                snackbar.showSnackbar(result.fold({ "Compra registrada #$it" }, { it.message ?: "No se pudo registrar la compra" }))
                            }
                        },
                        history = purchases.map { "${it.productNameSnapshot} · +${it.quantity} uds. · ${money(it.totalMinor, it.currency)}" }
                    )
                    Screen.SUPPLIERS -> SuppliersScreen(suppliers) { name, contact, notes ->
                        scope.launch {
                            try {
                                require(name.isNotBlank()) { "El nombre del proveedor es obligatorio." }
                                dao.insertSupplier(Supplier(name = name.trim(), contact = contact.trim(), notes = notes.trim()))
                                snackbar.showSnackbar("Proveedor guardado")
                            } catch (e: Exception) { snackbar.showSnackbar(e.message ?: "No se pudo guardar") }
                        }
                    }
                    Screen.ANALYSIS -> AnalysisScreen(products, sales, purchases)
                    Screen.SETTINGS -> SettingsScreen()
                }
            }
        }
    }
}

@Composable
private fun HomeScreen(products: List<Product>, sales: List<Sale>, purchases: List<Purchase>) {
    val inventoryValue = products.sumOf { it.costMinor * it.quantity }
    val revenue = sales.sumOf { it.totalMinor }
    val profit = sales.sumOf { it.grossProfitMinor }
    val low = products.count { it.quantity <= it.minimum }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Kpi("Productos", products.size.toString(), Modifier.weight(1f))
            Kpi("Stock bajo", low.toString(), Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Kpi("Valor a costo", money(inventoryValue, products.firstOrNull()?.currency ?: "USD"), Modifier.weight(1f))
            Kpi("Ventas", money(revenue, sales.firstOrNull()?.currency ?: "USD"), Modifier.weight(1f))
        }
        Kpi("Ganancia bruta", money(profit, sales.firstOrNull()?.currency ?: "USD"), Modifier.fillMaxWidth())
        Card(colors = CardDefaults.cardColors(containerColor = panel)) {
            Column(Modifier.padding(16.dp)) {
                Text("Estado local", style = MaterialTheme.typography.titleMedium, color = lime)
                Text("Datos guardados en el dispositivo mediante Room/SQLite.")
                Text("Compras registradas: ${purchases.size}")
                Text("La ganancia bruta no descuenta gastos ni impuestos.")
            }
        }
        Text("Productos con stock bajo", style = MaterialTheme.typography.titleMedium)
        products.filter { it.quantity <= it.minimum }.take(10).forEach {
            Text("• ${it.name}: ${it.quantity} disponibles (mínimo ${it.minimum})")
        }
        if (low == 0) Text("No hay alertas de stock mínimo.")
    }
}

@Composable
private fun Kpi(title: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier = modifier, colors = CardDefaults.cardColors(containerColor = panel)) {
        Column(Modifier.padding(14.dp)) {
            Text(title, style = MaterialTheme.typography.labelMedium)
            Spacer(Modifier.height(5.dp))
            Text(value, style = MaterialTheme.typography.titleLarge, color = lime)
        }
    }
}

@Composable
private fun ProductsScreen(products: List<Product>, onAdd: (String, String, Long, Long, Int, Int) -> Unit) {
    var sku by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var cost by remember { mutableStateOf("0.00") }
    var price by remember { mutableStateOf("0.00") }
    var quantity by remember { mutableStateOf("0") }
    var minimum by remember { mutableStateOf("0") }
    Column(Modifier.fillMaxSize()) {
        Card(colors = CardDefaults.cardColors(containerColor = panel)) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(sku, { sku = it }, label = { Text("SKU / código") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(name, { name = it }, label = { Text("Nombre del producto") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    MoneyField("Costo", cost, { cost = it }, Modifier.weight(1f))
                    MoneyField("Precio", price, { price = it }, Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    NumberField("Cantidad", quantity, { quantity = it }, Modifier.weight(1f))
                    NumberField("Mínimo", minimum, { minimum = it }, Modifier.weight(1f))
                }
                Button(onClick = {
                    val c = parseMoney(cost); val p = parseMoney(price)
                    val q = quantity.toIntOrNull(); val m = minimum.toIntOrNull()
                    if (c != null && p != null && q != null && m != null && sku.isNotBlank() && name.isNotBlank() && q >= 0 && m >= 0) {
                        onAdd(sku, name, c, p, q, m)
                        sku = ""; name = ""; cost = "0.00"; price = "0.00"; quantity = "0"; minimum = "0"
                    }
                }, modifier = Modifier.fillMaxWidth()) { Text("Guardar producto") }
            }
        }
        Spacer(Modifier.height(12.dp))
        Text("Inventario (${products.size})", style = MaterialTheme.typography.titleMedium)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(products, key = { it.id }) { p ->
                Card(colors = CardDefaults.cardColors(containerColor = panel), modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(p.name, style = MaterialTheme.typography.titleSmall)
                            Text("SKU: ${p.sku} · Mínimo: ${p.minimum}")
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("${p.quantity} uds.", color = if (p.quantity <= p.minimum) MaterialTheme.colorScheme.error else lime)
                            Text(money(p.priceMinor, p.currency))
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TransactionScreen(
    products: List<Product>,
    suppliers: List<Supplier>,
    showSupplier: Boolean,
    actionLabel: String,
    onSubmit: (Long, Int, Long, Long?) -> Unit,
    history: List<String>
) {
    var selectedProduct by remember { mutableStateOf<Long?>(null) }
    var quantity by remember { mutableStateOf("1") }
    var cost by remember { mutableStateOf("0.00") }
    var supplierId by remember { mutableStateOf<Long?>(null) }
    Column(Modifier.fillMaxSize()) {
        Card(colors = CardDefaults.cardColors(containerColor = panel)) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (products.isEmpty()) Text("Primero registra un producto en Inventario.")
                else {
                    var expanded by remember { mutableStateOf(false) }
                    ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = it }) {
                        OutlinedTextField(
                            value = products.firstOrNull { it.id == selectedProduct }?.let { "${it.name} · ${it.quantity} uds." } ?: "Selecciona un producto",
                            onValueChange = {}, readOnly = true, label = { Text("Producto") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) },
                            modifier = Modifier.menuAnchor().fillMaxWidth()
                        )
                        ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                            products.forEach { product ->
                                DropdownMenuItem(text = { Text("${product.name} · ${product.quantity} uds.") }, onClick = {
                                    selectedProduct = product.id
                                    cost = "%.2f".format(Locale.US, product.costMinor / 100.0)
                                    expanded = false
                                })
                            }
                        }
                    }
                    NumberField("Cantidad", quantity, { quantity = it }, Modifier.fillMaxWidth())
                    if (showSupplier) {
                        var supplierExpanded by remember { mutableStateOf(false) }
                        ExposedDropdownMenuBox(expanded = supplierExpanded, onExpandedChange = { supplierExpanded = it }) {
                            OutlinedTextField(
                                value = suppliers.firstOrNull { it.id == supplierId }?.name ?: "Proveedor (opcional)",
                                onValueChange = {}, readOnly = true, label = { Text("Proveedor") },
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(supplierExpanded) },
                                modifier = Modifier.menuAnchor().fillMaxWidth()
                            )
                            ExposedDropdownMenu(expanded = supplierExpanded, onDismissRequest = { supplierExpanded = false }) {
                                DropdownMenuItem(text = { Text("Sin proveedor") }, onClick = { supplierId = null; supplierExpanded = false })
                                suppliers.forEach { s -> DropdownMenuItem(text = { Text(s.name) }, onClick = { supplierId = s.id; supplierExpanded = false }) }
                            }
                        }
                        MoneyField("Costo unitario de compra", cost, { cost = it }, Modifier.fillMaxWidth())
                    }
                    Button(onClick = {
                        val q = quantity.toIntOrNull()
                        val c = parseMoney(cost)
                        val id = selectedProduct
                        if (id != null && q != null && q > 0 && (!showSupplier || c != null)) {
                            onSubmit(id, q, if (showSupplier) c!! else 0L, supplierId)
                        }
                    }, modifier = Modifier.fillMaxWidth()) { Text(actionLabel) }
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Text("Historial", style = MaterialTheme.typography.titleMedium)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(history) { line -> Card(colors = CardDefaults.cardColors(containerColor = panel)) { Text(line, Modifier.padding(12.dp)) } }
        }
    }
}

@Composable
private fun SuppliersScreen(suppliers: List<Supplier>, onAdd: (String, String, String) -> Unit) {
    var name by remember { mutableStateOf("") }
    var contact by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize()) {
        Card(colors = CardDefaults.cardColors(containerColor = panel)) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Nombre del proveedor") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(contact, { contact = it }, label = { Text("Contacto") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(notes, { notes = it }, label = { Text("Notas") }, modifier = Modifier.fillMaxWidth())
                Button(onClick = { if (name.isNotBlank()) { onAdd(name, contact, notes); name = ""; contact = ""; notes = "" } }, modifier = Modifier.fillMaxWidth()) { Text("Guardar proveedor") }
            }
        }
        Spacer(Modifier.height(12.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(suppliers, key = { it.id }) { s ->
                Card(colors = CardDefaults.cardColors(containerColor = panel)) {
                    Column(Modifier.padding(12.dp)) {
                        Text(s.name, style = MaterialTheme.typography.titleMedium)
                        if (s.contact.isNotBlank()) Text(s.contact)
                        if (s.notes.isNotBlank()) Text(s.notes)
                    }
                }
            }
        }
    }
}

@Composable
private fun AnalysisScreen(products: List<Product>, sales: List<Sale>, purchases: List<Purchase>) {
    val revenue = sales.sumOf { it.totalMinor }
    val profit = sales.sumOf { it.grossProfitMinor }
    val unitsSold = sales.sumOf { it.quantity }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Kpi("Ingresos brutos", money(revenue, sales.firstOrNull()?.currency ?: "USD"), Modifier.fillMaxWidth())
        Kpi("Ganancia bruta", money(profit, sales.firstOrNull()?.currency ?: "USD"), Modifier.fillMaxWidth())
        Kpi("Unidades vendidas", unitsSold.toString(), Modifier.fillMaxWidth())
        Kpi("Compras registradas", purchases.size.toString(), Modifier.fillMaxWidth())
        Kpi("Valor inventario a costo", money(products.sumOf { it.costMinor * it.quantity }, products.firstOrNull()?.currency ?: "USD"), Modifier.fillMaxWidth())
        Text("Indicadores locales. No se convierten importes de distintas monedas.")
    }
}

@Composable
private fun SettingsScreen() {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Card(colors = CardDefaults.cardColors(containerColor = panel)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Almacenamiento local", style = MaterialTheme.typography.titleMedium, color = lime)
                Text("Room/SQLite mantiene los datos entre reinicios.")
                Text("La base de datos aún no está cifrada en esta versión.")
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = panel)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Copias y migración", style = MaterialTheme.typography.titleMedium, color = lime)
                Text("Importación de datos web y copia cifrada: pendientes. Conserva la versión web y no borres sus datos.")
                Text("Licencias offline, sincronización, multimoneda y traducción completa: pendientes.")
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = panel)) {
            Column(Modifier.padding(16.dp)) {
                Text("Versión 0.1.0 · Migración inicial")
                Text("No usar como sistema de producción hasta completar pruebas de integridad y recuperación.")
            }
        }
    }
}

@Composable
private fun NumberField(label: String, value: String, onValueChange: (String) -> Unit, modifier: Modifier = Modifier) {
    OutlinedTextField(value, { onValueChange(it.filter(Char::isDigit)) }, label = { Text(label) },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = modifier)
}

@Composable
private fun MoneyField(label: String, value: String, onValueChange: (String) -> Unit, modifier: Modifier = Modifier) {
    OutlinedTextField(value, { new -> onValueChange(new.filter { it.isDigit() || it == '.' || it == ',' }.replace(',', '.')) },
        label = { Text(label) }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
        singleLine = true, modifier = modifier)
}

private fun parseMoney(value: String): Long? {
    val parsed = value.toBigDecimalOrNull() ?: return null
    if (parsed.signum() < 0 || parsed.scale() > 2) return null
    return try { parsed.movePointRight(2).longValueExact() } catch (_: Exception) { null }
}

private fun money(minor: Long, currency: String): String {
    return if (currency == "CUP") {
        String.format(Locale.US, "%.2f CUP", minor / 100.0)
    } else {
        val format = NumberFormat.getCurrencyInstance(Locale.US)
        format.currency = java.util.Currency.getInstance(currency)
        format.format(minor / 100.0)
    }
}
