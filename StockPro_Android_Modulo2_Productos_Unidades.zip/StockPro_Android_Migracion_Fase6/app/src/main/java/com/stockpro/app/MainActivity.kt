package com.stockpro.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.background
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.room.Room
import com.stockpro.app.data.*
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.util.Locale

private val deepGreen = Color(0xFF031A16)
private val panel = Color(0xFF082923)
private val panelRaised = Color(0xFF0D352D)
private val lime = Color(0xFFB8F34A)
private val mint = Color(0xFF35D69A)
private val cyan = Color(0xFF23C8D9)
private val blue = Color(0xFF258BFF)
private val purple = Color(0xFF8855F7)
private val orange = Color(0xFFFF9B35)
private val mutedText = Color(0xFFA9C1B9)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = Room.databaseBuilder(applicationContext, StockDatabase::class.java, "stockpro.db")
            .addMigrations(StockDatabase.MIGRATION_1_2)
            .build()
        setContent { StockProApp(db.dao()) }
    }
}

private enum class Screen(val label: String) {
    HOME("Inicio"), PRODUCTS("Productos"), SALES("Ventas"), PURCHASES("Compras"),
    SUPPLIERS("Proveedores"), ANALYSIS("Análisis"), SETTINGS("Ajustes"), LOW_STOCK("Stock bajo")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun StockProApp(dao: StockDao) {
    var screen by remember { mutableStateOf(Screen.HOME) }
    var moreExpanded by remember { mutableStateOf(false) }
    val products by dao.observeProducts().collectAsStateWithLifecycle(initialValue = emptyList())
    val suppliers by dao.observeSuppliers().collectAsStateWithLifecycle(initialValue = emptyList())
    val sales by dao.observeSales().collectAsStateWithLifecycle(initialValue = emptyList())
    val purchases by dao.observePurchases().collectAsStateWithLifecycle(initialValue = emptyList())
    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    MaterialTheme(colorScheme = darkColorScheme(
        primary = lime, onPrimary = deepGreen, background = deepGreen, surface = panel,
        onBackground = Color.White, onSurface = Color.White,
        secondary = mint, onSurfaceVariant = mutedText, outline = Color(0xFF31564D),
        error = Color(0xFFFF6B5F)
    )) {
        Scaffold(
            containerColor = deepGreen,
            snackbarHost = { SnackbarHost(snackbar) },
            bottomBar = {
                NavigationBar(
                    containerColor = Color(0xFF061F1A),
                    contentColor = mutedText,
                    tonalElevation = 0.dp
                ) {
                    val mainItems = listOf(
                        Screen.HOME to Icons.Default.Home,
                        Screen.PRODUCTS to Icons.Default.Inventory2,
                        Screen.SALES to Icons.Default.PointOfSale,
                        Screen.PURCHASES to Icons.Default.ShoppingCart
                    )
                    mainItems.forEach { (item, icon) ->
                        NavigationBarItem(
                            selected = screen == item,
                            onClick = { screen = item },
                            icon = { Icon(icon, contentDescription = item.label) },
                            label = { Text(if (item == Screen.PRODUCTS) "Inventario" else item.label, maxLines = 1) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = lime, selectedTextColor = lime,
                                indicatorColor = Color(0xFF183D2C), unselectedIconColor = mutedText,
                                unselectedTextColor = mutedText
                            )
                        )
                    }
                    Box {
                        NavigationBarItem(
                            selected = screen == Screen.SUPPLIERS || screen == Screen.ANALYSIS || screen == Screen.SETTINGS,
                            onClick = { moreExpanded = true },
                            icon = { Icon(Icons.Default.MoreHoriz, contentDescription = "Más opciones") },
                            label = { Text("Más", maxLines = 1) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = lime, selectedTextColor = lime,
                                indicatorColor = Color(0xFF183D2C), unselectedIconColor = mutedText,
                                unselectedTextColor = mutedText
                            )
                        )
                        DropdownMenu(expanded = moreExpanded, onDismissRequest = { moreExpanded = false },
                            modifier = Modifier.background(panel)) {
                            listOf(Screen.SUPPLIERS, Screen.ANALYSIS, Screen.SETTINGS).forEach { item ->
                                DropdownMenuItem(
                                    text = { Text(item.label, color = Color.White) },
                                    leadingIcon = {
                                        Icon(when (item) {
                                            Screen.SUPPLIERS -> Icons.Default.People
                                            Screen.ANALYSIS -> Icons.Default.Analytics
                                            else -> Icons.Default.Settings
                                        }, contentDescription = null, tint = lime)
                                    },
                                    onClick = { screen = item; moreExpanded = false }
                                )
                            }
                        }
                    }
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding)) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    androidx.compose.foundation.Image(
                        painter = painterResource(id = R.drawable.stockpro_logo),
                        contentDescription = "Logotipo StockPro",
                        modifier = Modifier.size(40.dp).border(1.dp, Color(0xFF396B38), RoundedCornerShape(12.dp))
                    )
                    Spacer(Modifier.width(9.dp))
                    Column(Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Stock", style = MaterialTheme.typography.titleLarge, color = Color.White)
                            Text("Pro", style = MaterialTheme.typography.titleLarge, color = lime)
                        }
                        Text("Tu negocio en buenas manos", style = MaterialTheme.typography.labelSmall, color = mutedText)
                    }
                    IconButton(onClick = { screen = Screen.SETTINGS }) {
                        Icon(Icons.Default.AccountCircle, contentDescription = "Configuración", tint = lime, modifier = Modifier.size(29.dp))
                    }
                }
                if (screen != Screen.HOME) {
                    Text(screen.label, style = MaterialTheme.typography.headlineSmall, color = Color.White,
                        modifier = Modifier.padding(start = 18.dp, end = 18.dp, bottom = 12.dp))
                }
                Box(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
                    when (screen) {
                        Screen.HOME -> HomeScreen(products, sales, purchases, onLowStock = { screen = Screen.LOW_STOCK }, onAnalysis = { screen = Screen.ANALYSIS })
                        Screen.LOW_STOCK -> LowStockScreen(products.filter { it.quantity <= it.minimum })
                        Screen.PRODUCTS -> ProductsScreen(products) { sku, name, cost, price, qty, min, unit ->
                            scope.launch {
                                try {
                                    require(sku.isNotBlank() && name.isNotBlank()) { "SKU y nombre son obligatorios." }
                                    require(cost >= 0 && price >= 0 && qty >= 0 && min >= 0) { "No se permiten valores negativos." }
                                    dao.insertProduct(Product(sku = sku.trim(), name = name.trim(), costMinor = cost, priceMinor = price, quantity = qty, minimum = min, unitOfMeasure = unit))
                                    snackbar.showSnackbar("Producto guardado")
                                } catch (e: Exception) {
                                    snackbar.showSnackbar(e.message ?: "No se pudo guardar. Comprueba si el SKU ya existe.")
                                }
                            }
                        }
                        Screen.SALES -> TransactionScreen(
                            products = products, suppliers = emptyList(), showSupplier = false,
                            actionLabel = "Finalizar venta",
                            onSubmit = { id, qty, _, _ ->
                                scope.launch {
                                    val result = runCatching { dao.registerSale(id, qty).getOrThrow() }
                                    snackbar.showSnackbar(result.fold({ "Venta registrada #$it" }, { it.message ?: "No se pudo registrar la venta" }))
                                }
                            },
                            history = sales.map { "${it.productNameSnapshot} · ${it.quantity} uds. · ${money(it.totalMinor, it.currency)}" }
                        )
                        Screen.PURCHASES -> TransactionScreen(
                            products = products, suppliers = suppliers, showSupplier = true,
                            actionLabel = "Guardar compra",
                            onSubmit = { id, qty, cost, supplierId ->
                                scope.launch {
                                    val result = runCatching { dao.registerPurchase(id, qty, cost, supplierId).getOrThrow() }
                                    snackbar.showSnackbar(result.fold({ "Compra registrada #$it" }, { it.message ?: "No se pudo registrar la compra" }))
                                }
                            },
                            history = purchases.map { "${it.productNameSnapshot} · +${it.quantity} uds. · ${money(it.totalMinor, it.currency)}" }
                        )
                        Screen.SUPPLIERS -> SuppliersScreen(suppliers) { name, contact, notes ->
                            scope.launch {
                                try {
                                    require(name.isNotBlank()) { "El nombre del proveedor es obligatorio." }
                                    dao.insertSupplier(Supplier(name = name.trim(), contact = contact.trim(), notes = notes.trim()))
                                    snackbar.showSnackbar("Proveedor guardado")
                                } catch (e: Exception) { snackbar.showSnackbar(e.message ?: "No se pudo guardar") }
                            }
                        }
                        Screen.ANALYSIS -> AnalysisScreen(products, sales, purchases)
                        Screen.SETTINGS -> SettingsScreen()
                    }
                }
            }
        }
    }
}

@Composable
private fun HomeScreen(
    products: List<Product>,
    sales: List<Sale>,
    purchases: List<Purchase>,
    onLowStock: () -> Unit,
    onAnalysis: () -> Unit
) {
    val now = System.currentTimeMillis()
    val todayStart = remember { java.util.Calendar.getInstance().apply {
        set(java.util.Calendar.HOUR_OF_DAY, 0); set(java.util.Calendar.MINUTE, 0)
        set(java.util.Calendar.SECOND, 0); set(java.util.Calendar.MILLISECOND, 0)
    }.timeInMillis }
    val monthStart = remember { java.util.Calendar.getInstance().apply {
        set(java.util.Calendar.DAY_OF_MONTH, 1); set(java.util.Calendar.HOUR_OF_DAY, 0)
        set(java.util.Calendar.MINUTE, 0); set(java.util.Calendar.SECOND, 0)
        set(java.util.Calendar.MILLISECOND, 0)
    }.timeInMillis }
    val todaySales = sales.filter { it.date in todayStart..now }
    val monthSales = sales.filter { it.date in monthStart..now }
    val inventoryValue = products.sumOf { it.costMinor * it.quantity }
    val todayRevenue = todaySales.sumOf { it.totalMinor }
    val todayProfit = todaySales.sumOf { it.grossProfitMinor }
    val monthRevenue = monthSales.sumOf { it.totalMinor }
    val monthProfit = monthSales.sumOf { it.grossProfitMinor }
    val lowProducts = products.filter { it.quantity <= it.minimum }.sortedBy { it.quantity - it.minimum }
    val currency = products.firstOrNull()?.currency ?: sales.firstOrNull()?.currency ?: purchases.firstOrNull()?.currency ?: "USD"
    val averageTicket = if (monthSales.isNotEmpty()) monthRevenue / monthSales.size else 0L
    val marginPercent = if (monthRevenue > 0L) (monthProfit.toDouble() / monthRevenue.toDouble() * 100.0) else 0.0

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        androidx.compose.foundation.Image(
            painter = painterResource(id = R.drawable.stockpro_banner),
            contentDescription = "Banner promocional de StockPro: tu negocio en buenas manos",
            contentScale = ContentScale.FillWidth,
            modifier = Modifier.fillMaxWidth().aspectRatio(1.75f).clip(RoundedCornerShape(22.dp))
                .border(1.dp, Color(0xFF235440), RoundedCornerShape(22.dp))
        )

        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text("Resumen de hoy", style = MaterialTheme.typography.titleLarge, color = Color.White)
                Text(java.text.SimpleDateFormat("EEEE, d 'de' MMMM", Locale("es")).format(java.util.Date()),
                    style = MaterialTheme.typography.bodySmall, color = mutedText)
            }
            Box(Modifier.size(42.dp).background(Color(0xFF183D2E), RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Insights, contentDescription = null, tint = lime)
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Kpi("Ventas de hoy", money(todayRevenue, currency), Modifier.weight(1f), mint, Icons.Default.PointOfSale)
            Kpi("Ganancia de hoy", money(todayProfit, currency), Modifier.weight(1f), purple, Icons.Default.TrendingUp)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Kpi("Productos", products.size.toString(), Modifier.weight(1f), blue, Icons.Default.Inventory2)
            Kpi("Stock bajo", lowProducts.size.toString(), Modifier.weight(1f), orange, Icons.Default.NotificationsActive, onClick = onLowStock)
        }

        Card(colors = CardDefaults.cardColors(containerColor = panel), shape = RoundedCornerShape(22.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1B4438)), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text("Rendimiento del mes", style = MaterialTheme.typography.titleMedium, color = Color.White)
                        Text("Desde el día 1 hasta hoy", style = MaterialTheme.typography.labelSmall, color = mutedText)
                    }
                    Box(Modifier.size(40.dp).background(Color(0xFF183D2E), RoundedCornerShape(13.dp)), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Insights, contentDescription = null, tint = lime)
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    MetricTile("Facturación", money(monthRevenue, currency), Icons.Default.AccountBalanceWallet, mint, Modifier.weight(1f))
                    MetricTile("Ticket promedio", money(averageTicket, currency), Icons.Default.ReceiptLong, cyan, Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    MetricTile("Margen bruto", String.format(Locale("es"), "%.1f%%", marginPercent), Icons.Default.Percent, purple, Modifier.weight(1f))
                    MetricTile("Valor a costo", money(inventoryValue, currency), Icons.Default.Warehouse, blue, Modifier.weight(1f))
                }
            }
        }

        Card(colors = CardDefaults.cardColors(containerColor = panel), shape = RoundedCornerShape(22.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1B4438)), modifier = Modifier.fillMaxWidth().clickable { onAnalysis() }) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text("Ventas de los últimos 7 días", style = MaterialTheme.typography.titleMedium, color = Color.White)
                        Text("Actividad de tu negocio", style = MaterialTheme.typography.labelSmall, color = mutedText)
                    }
                    Icon(Icons.Default.ArrowOutward, contentDescription = "Abrir análisis", tint = lime)
                }
                SalesMiniChart(sales)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.BarChart, contentDescription = null, tint = lime, modifier = Modifier.size(17.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Ver análisis completo", color = lime, style = MaterialTheme.typography.labelLarge)
                    Spacer(Modifier.weight(1f))
                    Text("${monthSales.size} ventas este mes", color = mutedText, style = MaterialTheme.typography.labelSmall)
                }
            }
        }

        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF2A2417)), shape = RoundedCornerShape(22.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF76552A)), modifier = Modifier.fillMaxWidth().clickable { onLowStock() }) {
            Row(Modifier.fillMaxWidth().padding(15.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Box(Modifier.size(46.dp).background(Color(0xFF49351C), RoundedCornerShape(15.dp)), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Inventory, contentDescription = null, tint = orange, modifier = Modifier.size(25.dp))
                }
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text(if (lowProducts.isEmpty()) "Inventario saludable" else "Necesitan reposición", style = MaterialTheme.typography.titleSmall, color = Color.White)
                    Text(if (lowProducts.isEmpty()) "Todos los productos están por encima del mínimo." else "${lowProducts.size} productos requieren atención. Toca para ver la lista.", color = Color(0xFFE8D8BD), style = MaterialTheme.typography.bodySmall)
                }
                Icon(Icons.Default.ChevronRight, contentDescription = "Ver productos con stock bajo", tint = orange)
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.padding(bottom = 10.dp)) {
            SummaryChip(Icons.Default.ShoppingBag, "${purchases.size} compras registradas", Modifier.weight(1f))
            SummaryChip(Icons.Default.TrendingUp, "${sales.size} ventas totales", Modifier.weight(1f))
        }
    }
}

@Composable
private fun MetricTile(title: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, accent: Color, modifier: Modifier = Modifier) {
    Column(modifier.background(Color(0xFF0A211C), RoundedCornerShape(17.dp)).border(1.dp, Color(0xFF1B3C32), RoundedCornerShape(17.dp)).padding(12.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Icon(icon, contentDescription = null, tint = accent, modifier = Modifier.size(17.dp))
            Text(title, color = mutedText, style = MaterialTheme.typography.labelSmall, maxLines = 1)
        }
        Text(value, color = Color.White, style = MaterialTheme.typography.titleSmall, maxLines = 2)
    }
}

@Composable
private fun SummaryChip(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, modifier: Modifier = Modifier) {
    Row(modifier.background(panel, RoundedCornerShape(14.dp)).border(1.dp, Color(0xFF1B4438), RoundedCornerShape(14.dp)).padding(horizontal = 10.dp, vertical = 11.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
        Icon(icon, contentDescription = null, tint = lime, modifier = Modifier.size(17.dp))
        Text(label, color = mutedText, style = MaterialTheme.typography.labelSmall, maxLines = 2)
    }
}

@Composable
private fun LowStockScreen(products: List<Product>) {
    Column(Modifier.fillMaxSize()) {
        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF2A2417)), shape = RoundedCornerShape(20.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF76552A)), modifier = Modifier.fillMaxWidth()) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Box(Modifier.size(48.dp).background(Color(0xFF49351C), RoundedCornerShape(15.dp)), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.WarningAmber, contentDescription = null, tint = orange, modifier = Modifier.size(27.dp))
                }
                Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text("Control de reposición", color = Color.White, style = MaterialTheme.typography.titleMedium)
                    Text("${products.size} productos en el nivel mínimo o por debajo", color = Color(0xFFE8D8BD), style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        Spacer(Modifier.height(14.dp))
        if (products.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = mint, modifier = Modifier.size(54.dp))
                    Text("¡Todo en orden!", color = Color.White, style = MaterialTheme.typography.titleLarge)
                    Text("No hay productos que necesiten reposición.", color = mutedText)
                }
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 18.dp)) {
                items(products, key = { it.id }) { product ->
                    val missing = (product.minimum - product.quantity).coerceAtLeast(0)
                    Card(colors = CardDefaults.cardColors(containerColor = panel), shape = RoundedCornerShape(18.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF4B3A25)), modifier = Modifier.fillMaxWidth()) {
                        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Box(Modifier.size(46.dp).background(Color(0xFF49351C), RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.Inventory2, contentDescription = null, tint = orange, modifier = Modifier.size(24.dp))
                            }
                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(product.name, color = Color.White, style = MaterialTheme.typography.titleSmall)
                                Text("SKU ${product.sku}", color = mutedText, style = MaterialTheme.typography.labelSmall)
                                Text("Mínimo: ${product.minimum} unidades", color = mutedText, style = MaterialTheme.typography.bodySmall)
                            }
                            Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text("${product.quantity}", color = orange, style = MaterialTheme.typography.headlineSmall)
                                Text("disponibles", color = mutedText, style = MaterialTheme.typography.labelSmall)
                                if (missing > 0) Text("Faltan $missing", color = Color(0xFFFFC66D), style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun Kpi(title: String, value: String, modifier: Modifier = Modifier, accent: Color = lime, icon: androidx.compose.ui.graphics.vector.ImageVector = Icons.Default.Insights, onClick: (() -> Unit)? = null) {
    Card(
        modifier = modifier.then(if (onClick != null) Modifier.clickable { onClick() } else Modifier),
        colors = CardDefaults.cardColors(containerColor = accent.copy(alpha = 0.12f)),
        shape = RoundedCornerShape(17.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, accent.copy(alpha = 0.36f))
    ) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(38.dp).background(accent.copy(alpha = 0.18f), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
                Icon(icon, contentDescription = null, tint = accent, modifier = Modifier.size(21.dp))
            }
            Spacer(Modifier.width(9.dp))
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.labelMedium, color = Color.White.copy(alpha = 0.88f))
                Spacer(Modifier.height(3.dp))
                Text(value, style = MaterialTheme.typography.titleSmall, color = Color.White, maxLines = 2, softWrap = true)
            }
        }
    }
}

@Composable
private fun SalesMiniChart(sales: List<Sale>) {
    val labels = listOf("Lun", "Mar", "Mié", "Jue", "Vie", "Sáb", "Dom")
    val values = remember(sales) {
        val now = java.util.Calendar.getInstance()
        val result = MutableList(7) { 0L }
        sales.forEach { sale ->
            val day = java.util.Calendar.getInstance().apply { timeInMillis = sale.date }
            val diff = ((now.timeInMillis - day.timeInMillis) / 86_400_000L).toInt()
            if (diff in 0..6) result[6 - diff] += sale.totalMinor
        }
        result
    }
    val maxValue = (values.maxOrNull() ?: 0L).coerceAtLeast(1L).toFloat()
    Column {
        androidx.compose.foundation.Canvas(Modifier.fillMaxWidth().height(132.dp)) {
            val chartBottom = size.height - 4.dp.toPx()
            val chartTop = 8.dp.toPx()
            val chartHeight = chartBottom - chartTop
            for (i in 0..3) {
                val y = chartTop + chartHeight * i / 3f
                drawLine(Color(0xFF1D4439), Offset(0f, y), Offset(size.width, y), strokeWidth = 1.dp.toPx())
            }
            val slot = size.width / 7f
            values.forEachIndexed { index, value ->
                val barHeight = (value / maxValue) * (chartHeight * 0.88f)
                val left = slot * index + slot * 0.23f
                drawRoundRect(
                    brush = androidx.compose.ui.graphics.Brush.verticalGradient(listOf(lime, mint)),
                    topLeft = Offset(left, chartBottom - barHeight),
                    size = Size(slot * 0.54f, barHeight.coerceAtLeast(3.dp.toPx())),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(5.dp.toPx(), 5.dp.toPx())
                )
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            labels.forEach { Text(it, color = mutedText, style = MaterialTheme.typography.labelSmall) }
        }
    }
}

@Composable
private fun InfoPill(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String) {
    Row(
        modifier = Modifier.background(panel, RoundedCornerShape(50)).border(1.dp, Color(0xFF1D4539), RoundedCornerShape(50)).padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = lime, modifier = Modifier.size(16.dp))
        Spacer(Modifier.width(6.dp))
        Text(label, color = mutedText, style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
private fun ProductsScreen(products: List<Product>, onAdd: (String, String, Long, Long, Int, Int, String) -> Unit) {
    var sku by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var cost by remember { mutableStateOf("") }
    var price by remember { mutableStateOf("") }
    var quantity by remember { mutableStateOf("") }
    var minimum by remember { mutableStateOf("") }
    var unitOfMeasure by remember { mutableStateOf("Unidad") }
    var unitMenuExpanded by remember { mutableStateOf(false) }
    var search by remember { mutableStateOf("") }
    var showForm by remember { mutableStateOf(false) }
    val filtered = products.filter { it.name.contains(search, true) || it.sku.contains(search, true) }
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = search, onValueChange = { search = it },
                placeholder = { Text("Buscar producto o código") }, leadingIcon = { Icon(Icons.Default.Search, null, tint = mutedText) },
                singleLine = true, modifier = Modifier.weight(1f), shape = RoundedCornerShape(16.dp)
            )
            FilledIconButton(onClick = { showForm = !showForm }, modifier = Modifier.size(54.dp), colors = IconButtonDefaults.filledIconButtonColors(containerColor = lime, contentColor = deepGreen)) {
                Icon(if (showForm) Icons.Default.Close else Icons.Default.Add, contentDescription = if (showForm) "Cerrar formulario" else "Agregar producto")
            }
        }
        if (showForm) {
            Card(colors = CardDefaults.cardColors(containerColor = panel), shape = RoundedCornerShape(20.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF234D40))) {
                Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    Text("Nuevo producto", style = MaterialTheme.typography.titleMedium, color = lime)
                    OutlinedTextField(sku, { sku = it }, label = { Text("SKU / código") }, singleLine = true, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(13.dp))
                    OutlinedTextField(name, { name = it }, label = { Text("Nombre del producto") }, singleLine = true, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(13.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        MoneyField("Costo", cost, { cost = it }, Modifier.weight(1f), clearOnFocus = true)
                        MoneyField("Precio", price, { price = it }, Modifier.weight(1f), clearOnFocus = true)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        NumberField("Cantidad", quantity, { quantity = it }, Modifier.weight(1f), clearOnFocus = true)
                        NumberField("Mínimo", minimum, { minimum = it }, Modifier.weight(1f), clearOnFocus = true)
                    }
                    Box(Modifier.fillMaxWidth()) {
                        OutlinedTextField(
                            value = unitOfMeasure,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Unidad de medida") },
                            trailingIcon = { Icon(Icons.Default.ExpandMore, contentDescription = "Elegir unidad") },
                            modifier = Modifier.fillMaxWidth().clickable { unitMenuExpanded = true },
                            shape = RoundedCornerShape(13.dp)
                        )
                        DropdownMenu(
                            expanded = unitMenuExpanded,
                            onDismissRequest = { unitMenuExpanded = false },
                            modifier = Modifier.background(panel)
                        ) {
                            listOf("Unidad", "Libra", "Kilogramo", "Gramo", "Litro", "Mililitro", "Metro", "Paquete", "Caja", "Docena").forEach { unit ->
                                DropdownMenuItem(
                                    text = { Text(unit, color = Color.White) },
                                    onClick = { unitOfMeasure = unit; unitMenuExpanded = false }
                                )
                            }
                        }
                    }
                    Text("Selecciona cómo se controla este producto: por unidad, peso, volumen o empaque.", color = mutedText, style = MaterialTheme.typography.bodySmall)
                    Button(onClick = {
                        val c = parseMoney(cost); val p = parseMoney(price)
                        val q = quantity.toIntOrNull(); val m = minimum.toIntOrNull()
                        if (c != null && p != null && q != null && m != null && sku.isNotBlank() && name.isNotBlank() && q >= 0 && m >= 0) {
                            onAdd(sku, name, c, p, q, m, unitOfMeasure)
                            sku = ""; name = ""; cost = ""; price = ""; quantity = ""; minimum = ""; unitOfMeasure = "Unidad"; showForm = false
                        }
                    }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) { Icon(Icons.Default.Save, null); Spacer(Modifier.width(8.dp)); Text("Guardar producto") }
                }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Inventario", style = MaterialTheme.typography.titleMedium, color = Color.White, modifier = Modifier.weight(1f))
            Text("${filtered.size} productos", style = MaterialTheme.typography.labelMedium, color = mutedText)
        }
        if (filtered.isEmpty()) {
            Card(colors = CardDefaults.cardColors(containerColor = panel), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Default.Inventory2, null, tint = lime, modifier = Modifier.size(38.dp))
                    Text(if (products.isEmpty()) "Tu inventario comienza aquí" else "No se encontraron productos", color = Color.White, style = MaterialTheme.typography.titleMedium)
                    Text(if (products.isEmpty()) "Pulsa + para registrar tu primer producto." else "Prueba con otro nombre o código.", color = mutedText)
                }
            }
        } else {
            LazyColumn(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 12.dp)) {
                items(filtered, key = { it.id }) { p ->
                    Card(colors = CardDefaults.cardColors(containerColor = panel), shape = RoundedCornerShape(17.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF173D33)), modifier = Modifier.fillMaxWidth()) {
                        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(44.dp).background(Color(0xFF173A2A), RoundedCornerShape(13.dp)), contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.Inventory2, contentDescription = null, tint = lime, modifier = Modifier.size(23.dp))
                            }
                            Spacer(Modifier.width(11.dp))
                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                Text(p.name, style = MaterialTheme.typography.titleSmall, color = Color.White)
                                Text("SKU ${p.sku}", style = MaterialTheme.typography.labelSmall, color = mutedText)
                                Text("${p.quantity} ${p.unitOfMeasure.lowercase()} · mínimo ${p.minimum} ${p.unitOfMeasure.lowercase()}", style = MaterialTheme.typography.labelSmall, color = if (p.quantity <= p.minimum) orange else mint)
                            }
                            Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(money(p.priceMinor, p.currency), color = Color.White, style = MaterialTheme.typography.titleSmall)
                                Text("Precio", color = mutedText, style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TransactionScreen(
    products: List<Product>,
    suppliers: List<Supplier>,
    showSupplier: Boolean,
    actionLabel: String,
    onSubmit: (Long, Int, Long, Long?) -> Unit,
    history: List<String>
) {
    var selectedProduct by remember { mutableStateOf<Long?>(null) }
    var quantity by remember { mutableStateOf("1") }
    var cost by remember { mutableStateOf("0.00") }
    var supplierId by remember { mutableStateOf<Long?>(null) }
    Column(Modifier.fillMaxSize()) {
        Card(colors = CardDefaults.cardColors(containerColor = panel)) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (products.isEmpty()) Text("Primero registra un producto en Inventario.")
                else {
                    var expanded by remember { mutableStateOf(false) }
                    ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = it }) {
                        OutlinedTextField(
                            value = products.firstOrNull { it.id == selectedProduct }?.let { "${it.name} · ${it.quantity} uds." } ?: "Selecciona un producto",
                            onValueChange = {}, readOnly = true, label = { Text("Producto") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) },
                            modifier = Modifier.menuAnchor().fillMaxWidth()
                        )
                        ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                            products.forEach { product ->
                                DropdownMenuItem(text = { Text("${product.name} · ${product.quantity} uds.") }, onClick = {
                                    selectedProduct = product.id
                                    cost = "%.2f".format(Locale.US, product.costMinor / 100.0)
                                    expanded = false
                                })
                            }
                        }
                    }
                    NumberField("Cantidad", quantity, { quantity = it }, Modifier.fillMaxWidth())
                    if (showSupplier) {
                        var supplierExpanded by remember { mutableStateOf(false) }
                        ExposedDropdownMenuBox(expanded = supplierExpanded, onExpandedChange = { supplierExpanded = it }) {
                            OutlinedTextField(
                                value = suppliers.firstOrNull { it.id == supplierId }?.name ?: "Proveedor (opcional)",
                                onValueChange = {}, readOnly = true, label = { Text("Proveedor") },
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(supplierExpanded) },
                                modifier = Modifier.menuAnchor().fillMaxWidth()
                            )
                            ExposedDropdownMenu(expanded = supplierExpanded, onDismissRequest = { supplierExpanded = false }) {
                                DropdownMenuItem(text = { Text("Sin proveedor") }, onClick = { supplierId = null; supplierExpanded = false })
                                suppliers.forEach { s -> DropdownMenuItem(text = { Text(s.name) }, onClick = { supplierId = s.id; supplierExpanded = false }) }
                            }
                        }
                        MoneyField("Costo unitario de compra", cost, { cost = it }, Modifier.fillMaxWidth())
                    }
                    Button(onClick = {
                        val q = quantity.toIntOrNull()
                        val c = parseMoney(cost)
                        val id = selectedProduct
                        if (id != null && q != null && q > 0 && (!showSupplier || c != null)) {
                            onSubmit(id, q, if (showSupplier) c!! else 0L, supplierId)
                        }
                    }, modifier = Modifier.fillMaxWidth()) { Text(actionLabel) }
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Text("Historial", style = MaterialTheme.typography.titleMedium)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(history) { line -> Card(colors = CardDefaults.cardColors(containerColor = panel)) { Text(line, Modifier.padding(12.dp)) } }
        }
    }
}

@Composable
private fun SuppliersScreen(suppliers: List<Supplier>, onAdd: (String, String, String) -> Unit) {
    var name by remember { mutableStateOf("") }
    var contact by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize()) {
        Card(colors = CardDefaults.cardColors(containerColor = panel)) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Nombre del proveedor") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(contact, { contact = it }, label = { Text("Contacto") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(notes, { notes = it }, label = { Text("Notas") }, modifier = Modifier.fillMaxWidth())
                Button(onClick = { if (name.isNotBlank()) { onAdd(name, contact, notes); name = ""; contact = ""; notes = "" } }, modifier = Modifier.fillMaxWidth()) { Text("Guardar proveedor") }
            }
        }
        Spacer(Modifier.height(12.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(suppliers, key = { it.id }) { s ->
                Card(colors = CardDefaults.cardColors(containerColor = panel)) {
                    Column(Modifier.padding(12.dp)) {
                        Text(s.name, style = MaterialTheme.typography.titleMedium)
                        if (s.contact.isNotBlank()) Text(s.contact)
                        if (s.notes.isNotBlank()) Text(s.notes)
                    }
                }
            }
        }
    }
}

@Composable
private fun AnalysisScreen(products: List<Product>, sales: List<Sale>, purchases: List<Purchase>) {
    val revenue = sales.sumOf { it.totalMinor }
    val profit = sales.sumOf { it.grossProfitMinor }
    val unitsSold = sales.sumOf { it.quantity }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Kpi("Ingresos brutos", money(revenue, sales.firstOrNull()?.currency ?: "USD"), Modifier.fillMaxWidth())
        Kpi("Ganancia bruta", money(profit, sales.firstOrNull()?.currency ?: "USD"), Modifier.fillMaxWidth())
        Kpi("Unidades vendidas", unitsSold.toString(), Modifier.fillMaxWidth())
        Kpi("Compras registradas", purchases.size.toString(), Modifier.fillMaxWidth())
        Kpi("Valor inventario a costo", money(products.sumOf { it.costMinor * it.quantity }, products.firstOrNull()?.currency ?: "USD"), Modifier.fillMaxWidth())
        Text("Indicadores locales. No se convierten importes de distintas monedas.")
    }
}

@Composable
private fun SettingsScreen() {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Card(colors = CardDefaults.cardColors(containerColor = panel)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Almacenamiento local", style = MaterialTheme.typography.titleMedium, color = lime)
                Text("Room/SQLite mantiene los datos entre reinicios.")
                Text("La base de datos aún no está cifrada en esta versión.")
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = panel)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Copias y migración", style = MaterialTheme.typography.titleMedium, color = lime)
                Text("Importación de datos web y copia cifrada: pendientes. Conserva la versión web y no borres sus datos.")
                Text("Licencias offline, sincronización, multimoneda y traducción completa: pendientes.")
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = panel)) {
            Column(Modifier.padding(16.dp)) {
                Text("Versión 0.1.0 · Migración inicial")
                Text("No usar como sistema de producción hasta completar pruebas de integridad y recuperación.")
            }
        }
    }
}

@Composable
private fun NumberField(label: String, value: String, onValueChange: (String) -> Unit, modifier: Modifier = Modifier, clearOnFocus: Boolean = false) {
    var wasFocused by remember(label) { mutableStateOf(false) }
    OutlinedTextField(
        value = value,
        onValueChange = { onValueChange(it.filter(Char::isDigit)) },
        label = { Text(label) },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        singleLine = true,
        modifier = if (clearOnFocus) modifier.onFocusChanged { state ->
            if (state.isFocused && !wasFocused) onValueChange("")
            wasFocused = state.isFocused
        } else modifier
    )
}

@Composable
private fun MoneyField(label: String, value: String, onValueChange: (String) -> Unit, modifier: Modifier = Modifier, clearOnFocus: Boolean = false) {
    var wasFocused by remember(label) { mutableStateOf(false) }
    OutlinedTextField(
        value = value,
        onValueChange = { new -> onValueChange(new.filter { it.isDigit() || it == '.' || it == ',' }.replace(',', '.')) },
        label = { Text(label) },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
        singleLine = true,
        modifier = if (clearOnFocus) modifier.onFocusChanged { state ->
            if (state.isFocused && !wasFocused) onValueChange("")
            wasFocused = state.isFocused
        } else modifier
    )
}

private fun parseMoney(value: String): Long? {
    val parsed = value.toBigDecimalOrNull() ?: return null
    if (parsed.signum() < 0 || parsed.scale() > 2) return null
    return try { parsed.movePointRight(2).longValueExact() } catch (_: Exception) { null }
}

private fun money(minor: Long, currency: String): String {
    return if (currency == "CUP") {
        String.format(Locale.US, "%.2f CUP", minor / 100.0)
    } else {
        val format = NumberFormat.getCurrencyInstance(Locale.US)
        format.currency = java.util.Currency.getInstance(currency)
        format.format(minor / 100.0)
    }
}
