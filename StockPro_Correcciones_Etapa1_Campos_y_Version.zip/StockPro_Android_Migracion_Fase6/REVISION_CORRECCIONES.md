# StockPro — revisión y correcciones por etapas

## Etapa 1 aplicada
- Corregido el borrado inesperado de los campos numéricos y monetarios al volver a enfocarlos. Los campos ya no se vacían automáticamente al tocar o recuperar el foco.
- La creación de productos sigue iniciando con los campos vacíos y los limpia después de guardar correctamente.
- Corregido el texto de versión en Ajustes para que coincida con `versionName = 0.2.0`.
- No se alteró el esquema de Room ni se modificaron las cantidades almacenadas; esta etapa evita una migración de datos arriesgada.

## Pendientes de las siguientes etapas
1. Añadir edición real de productos, incluyendo SKU y unidad de medida, con validación de SKU único.
2. Diseñar una migración compatible para cantidades fraccionarias. No cambiar `Int` a decimal sin migrar y probar productos, ventas, compras y movimientos de inventario como conjunto.
3. Corregir unidades mostradas en ventas/compras/historial y revisar cálculos de estadísticas.
4. Mejorar pruebas de DAO y migraciones, y validar compilación en GitHub Actions.
5. Diseñar respaldo/restauración con comprobaciones de integridad y sin borrar datos automáticamente.

## Verificación
- Esta entrega es una corrección de código fuente empaquetada; no se afirma que haya pasado una compilación Android completa en este entorno.
- Antes de instalar una nueva APK, conservar una copia de seguridad de los datos actuales y comprobar la compilación en GitHub Actions.
- Añadida edición de productos existentes: SKU, nombre, costo, precio, cantidad, mínimo y unidad de medida.
- La actualización del producto y el registro de movimiento por cambio manual de cantidad se ejecutan dentro de una transacción Room. Si falla la actualización, el formulario conserva lo escrito y permite corregirlo.
- Se conserva el identificador del producto y la unicidad del SKU sigue protegida por el índice de la base de datos.
