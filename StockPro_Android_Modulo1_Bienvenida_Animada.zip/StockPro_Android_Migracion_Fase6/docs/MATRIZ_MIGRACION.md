# Matriz de migración web → Android

| Función | Estado en Android 0.1.0 | Trabajo pendiente |
|---|---|---|
| Dashboard y KPI | Inicial | Conciliar resultados con escenarios de prueba |
| Productos e inventario | Alta/listado, SKU único | Edición, búsqueda, borrado lógico, ajustes auditados |
| Ventas | Venta individual, control de stock y movimiento transaccional | Carrito multiproducto, devoluciones, impuestos y recibos |
| Compras | Compra individual y costo promedio ponderado | Recepción parcial y validación de redondeos |
| Proveedores | Alta/listado; selección opcional en compra | Edición, búsqueda y ficha completa |
| Movimientos | Se registran en compras/ventas | Pantalla de auditoría y ajustes manuales |
| Análisis | Ingresos, ganancia bruta, unidades, valor a costo | Fechas, gráficos y productos principales |
| USD/CUP | Código de moneda en producto y operación | Preferencias, tasas y reportes consolidados |
| Español/inglés | Interfaz inicial en español | Recursos de traducción completos |
| Exportación CSV | Pendiente | Selector de archivos y exportación |
| Backup JSON/cifrado | Pendiente | Formato versionado, cifrado, checksum e importación atómica |
| Licencias offline | Pendiente | Verificador nativo y pruebas de firma/expiración |
| Sincronización | No implementada | API, resolución de conflictos y controles de seguridad |

## Requisitos de la futura importación
La importación debe validar esquema, identificadores, monedas, cantidades y duplicados; mostrar resumen antes de confirmar; ejecutarse en transacción y abortar sin alterar la base si detecta inconsistencias.
