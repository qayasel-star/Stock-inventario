package com.stockpro.app

import org.junit.Assert.assertEquals
import org.junit.Test

class StockMathTest {
    @Test fun minorUnitsStayExactForSimpleAmounts() {
        assertEquals(1250L, "12.50".toBigDecimal().movePointRight(2).longValueExact())
    }

    @Test fun grossProfitIsRevenueLessCost() {
        val quantity = 3
        val priceMinor = 500L
        val costMinor = 200L
        assertEquals(900L, (priceMinor - costMinor) * quantity)
    }

    @Test fun cupIsASeparateCurrencyCode() {
        assertEquals("CUP", "CUP")
    }
}
