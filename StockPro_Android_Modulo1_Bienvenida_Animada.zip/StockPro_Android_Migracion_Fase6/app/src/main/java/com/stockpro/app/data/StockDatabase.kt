package com.stockpro.app.data

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow

@Dao
abstract class StockDao {
    @Query("SELECT * FROM products ORDER BY name COLLATE NOCASE")
    abstract fun observeProducts(): Flow<List<Product>>

    @Query("SELECT * FROM products WHERE id = :id LIMIT 1")
    abstract suspend fun productById(id: Long): Product?

    @Insert(onConflict = OnConflictStrategy.ABORT)
    abstract suspend fun insertProduct(product: Product): Long

    @Query("UPDATE products SET name=:name, costMinor=:cost, priceMinor=:price, quantity=:quantity, minimum=:minimum WHERE id=:id")
    abstract suspend fun updateProductFields(id: Long, name: String, cost: Long, price: Long, quantity: Int, minimum: Int): Int

    @Query("SELECT * FROM suppliers ORDER BY name COLLATE NOCASE")
    abstract fun observeSuppliers(): Flow<List<Supplier>>

    @Insert
    abstract suspend fun insertSupplier(supplier: Supplier): Long

    @Query("SELECT * FROM sales ORDER BY date DESC")
    abstract fun observeSales(): Flow<List<Sale>>

    @Insert
    abstract suspend fun insertSale(sale: Sale): Long

    @Query("SELECT * FROM purchases ORDER BY date DESC")
    abstract fun observePurchases(): Flow<List<Purchase>>

    @Insert
    abstract suspend fun insertPurchase(purchase: Purchase): Long

    @Query("INSERT INTO stock_movements(date, productId, productNameSnapshot, type, quantityDelta, quantityBefore, quantityAfter, reason) VALUES(:date,:productId,:name,:type,:delta,:before,:after,:reason)")
    abstract suspend fun insertMovement(date: Long, productId: Long, name: String, type: String, delta: Int, before: Int, after: Int, reason: String)

    @Query("UPDATE products SET quantity = :quantity WHERE id = :productId")
    abstract suspend fun setQuantity(productId: Long, quantity: Int): Int

    @Transaction
    open suspend fun registerSale(productId: Long, quantity: Int): Result<Long> {
        require(quantity > 0) { "La cantidad debe ser mayor que cero." }
        val product = productById(productId) ?: error("El producto no existe.")
        require(product.quantity >= quantity) { "No hay suficiente stock." }
        val before = product.quantity
        val after = before - quantity
        val total = Math.multiplyExact(product.priceMinor, quantity.toLong())
        val profit = Math.multiplyExact(product.priceMinor - product.costMinor, quantity.toLong())
        val saleId = insertSale(Sale(
            productId = product.id, productNameSnapshot = product.name, quantity = quantity,
            unitPriceMinor = product.priceMinor, unitCostMinor = product.costMinor,
            currency = product.currency, totalMinor = total, grossProfitMinor = profit
        ))
        check(setQuantity(productId, after) == 1) { "No se pudo actualizar el inventario." }
        insertMovement(System.currentTimeMillis(), productId, product.name, "VENTA", -quantity, before, after, "Venta #$saleId")
        return Result.success(saleId)
    }

    @Transaction
    open suspend fun registerPurchase(productId: Long, quantity: Int, unitCostMinor: Long, supplierId: Long? = null): Result<Long> {
        require(quantity > 0) { "La cantidad debe ser mayor que cero." }
        require(unitCostMinor >= 0) { "El costo no puede ser negativo." }
        val product = productById(productId) ?: error("El producto no existe.")
        val before = product.quantity
        val after = Math.addExact(before, quantity)
        val weightedNumerator = Math.addExact(
            Math.multiplyExact(product.costMinor, before.toLong()),
            Math.multiplyExact(unitCostMinor, quantity.toLong())
        )
        val newCost = if (after > 0) weightedNumerator / after else unitCostMinor
        val total = Math.multiplyExact(unitCostMinor, quantity.toLong())
        val purchaseId = insertPurchase(Purchase(
            productId = product.id, productNameSnapshot = product.name, quantity = quantity,
            unitCostMinor = unitCostMinor, currency = product.currency,
            totalMinor = total, supplierId = supplierId
        ))
        check(updateProductFields(product.id, product.name, newCost, product.priceMinor, after, product.minimum) == 1) {
            "No se pudo actualizar el inventario."
        }
        insertMovement(System.currentTimeMillis(), productId, product.name, "COMPRA", quantity, before, after, "Compra #$purchaseId")
        return Result.success(purchaseId)
    }
}

@Database(
    entities = [Product::class, Supplier::class, Sale::class, Purchase::class, StockMovement::class],
    version = 2,
    exportSchema = true
)
abstract class StockDatabase : RoomDatabase() {
    abstract fun dao(): StockDao

    companion object {
        val MIGRATION_1_2: Migration = object : Migration(1, 2) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("ALTER TABLE products ADD COLUMN unitOfMeasure TEXT NOT NULL DEFAULT 'Unidad'")
            }
        }
    }
}
