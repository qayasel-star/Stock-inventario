# StockPro Android — Fase 6: migración nativa inicial

Este proyecto inicia la conversión de StockPro a Android nativo con Kotlin, Jetpack Compose y Room/SQLite.

## Qué incluye esta base
- Aplicación Android nativa con navegación inferior.
- Inventario: alta y listado de productos, SKU único, cantidades y stock mínimo.
- Proveedores: alta y listado.
- Ventas: registro transaccional, control de stock disponible, instantánea de precio/costo y movimiento de inventario.
- Compras: registro transaccional, incremento de stock y cálculo inicial del costo promedio ponderado.
- Inicio y análisis con indicadores básicos.
- GitHub Actions para compilar APK debug y ejecutar pruebas unitarias.
- El ZIP web original y el paquete previo de integridad se conservan intactos en `legacy/`.

## Importante: alcance
Esta es una migración inicial funcional de los flujos básicos, no una equivalencia completa con la versión web. Todavía faltan edición/búsqueda avanzada de productos, carrito con varios productos, devoluciones, ajustes manuales auditados, importador de datos, exportación CSV, backup cifrado, licencias offline, sincronización, traducciones completas y pruebas de integración.

No se declara que la base de datos esté cifrada. No usar en producción hasta completar las pruebas de recuperación y la migración de datos.

## Abrir y compilar
1. Descomprime el ZIP.
2. Abre la carpeta `StockPro_Android_Migracion_Fase6` en Android Studio.
3. Usa JDK 17 y Android SDK 35.
4. Sincroniza Gradle y ejecuta la app en un dispositivo/emulador.
5. Para compilar por terminal: `gradle --no-daemon testDebugUnitTest assembleDebug` (requiere Gradle, JDK 17 y Android SDK instalados).

El workflow `.github/workflows/android.yml` ejecuta las pruebas y compila el APK. El artefacto se publica solo si la compilación termina correctamente.

## Datos: procedimiento seguro
- No borres el navegador, el almacenamiento web ni el ZIP original.
- No importes directamente datos de `localStorage` a SQLite.
- Esta entrega todavía no incluye importación automática del JSON web.
- La siguiente fase debe implementar importador versionado, validar registros y duplicados, mostrar una vista previa y confirmar la importación en una transacción atómica.

## Firma de publicación
Para futuras actualizaciones usa una keystore permanente. Guárdala fuera del repositorio y no subas la keystore ni sus contraseñas. La APK debug no es la versión firmada de publicación.


## Fase visual 2 — estilo StockPro verde oscuro/lima

Esta versión incorpora una renovación de la interfaz Android inspirada en la referencia visual del proyecto:

- Paleta verde petróleo, verde lima, menta y tarjetas de KPI en azul, violeta y naranja.
- Cabecera de marca StockPro y eslogan.
- Panel principal con resumen de ventas, ganancias, productos y stock bajo.
- Gráfico semanal local calculado con ventas guardadas.
- Alertas de inventario y estado de almacenamiento local.
- Barra de navegación compacta: Inicio, Inventario, Ventas, Compras y Más.
- Búsqueda de productos, formulario de alta desplegable y tarjetas de inventario.
- Icono vectorial propio para la aplicación.

**Alcance:** es una mejora visual y de navegación sobre la migración Android. No significa que todas las funciones de la referencia (inicio de sesión, licencias, vencimientos, sincronización o copias cifradas) estén implementadas. Los importes y el gráfico se basan en registros locales; no se inventan datos para completar el panel.

**Validación:** el archivo fuente se ha actualizado, pero esta sesión no dispone de Gradle/Android SDK para ejecutar una compilación local. Ejecuta el workflow Android CI de GitHub y revisa que `testDebugUnitTest` y `assembleDebug` terminen correctamente antes de instalar el APK.


## Banner promocional integrado
Se incorporó `app/src/main/res/drawable-nodpi/stockpro_banner.png` y se muestra en la parte superior del panel Inicio, con recorte adaptativo y bordes redondeados. Para validar la compilación, ejecuta `./gradlew assembleDebug` o el workflow Android CI de GitHub Actions.


## Icono de la aplicación
Se configuró `@mipmap/ic_launcher` en el manifiesto, con iconos para densidades mdpi–xxxhdpi y un icono adaptativo para Android 8.0 o posterior. El icono aparece en el lanzador después de compilar e instalar esta versión.


## Módulo 1: Bienvenida animada

Se incorporó una pantalla de bienvenida Compose con animación suave del logotipo, anillos de luz, identidad verde petróleo/verde lima y barra de progreso visual. Después de aproximadamente 2,6 segundos pasa automáticamente a la pantalla Inicio. La barra es decorativa y no representa el progreso real de carga de la base de datos.
